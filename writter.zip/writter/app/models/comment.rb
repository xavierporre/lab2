class Comment < ApplicationRecord
    # Validations
    validates :content, presence: true
    validates :author, presence: true, email_exists: true
  
    belongs_to :post
  end
  