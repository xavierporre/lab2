class Post < ApplicationRecord
    # Validations
    validates :title, presence: true, length: { maximum: 100 }
    validates :content, presence: true, length: { minimum: 140 }
    validates :published, presence: true, inclusion: { in: [0, 1] }
    validates :author, presence: true, email_exists: true
  
    # Enum for the published attribute
    enum published: { unpublished: 0, published: 1 }
  end
  