class EmailExistsValidator < ActiveModel::EachValidator
    def validate_each(record, attribute, value)
      unless User.exists?(email: value)
        record.errors.add(attribute, "must be the email of an existing user")
      end
    end
  end
  