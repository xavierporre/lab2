# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
# db/seeds.rb

# Clear existing data
User.destroy_all
Post.destroy_all
Comment.destroy_all

# Create Users
10.times do |i|
  User.create!(
    email: "user#{i+1}@example.com",
    first_name: "FirstName#{i+1}",
    last_name: "LastName#{i+1}"
  )
end
puts "10 Users created."

# Create Posts
10.times do |i|
  Post.create!(
    title: "Post Title #{i+1}",
    content: "This is the content of post #{i+1}. " + "Content goes here. " * 7,
    published: i.even? ? :published : :unpublished,
    author: User.all.sample.email
  )
end
puts "10 Posts created."

# Create Comments
10.times do |i|
  Comment.create!(
    content: "This is a comment #{i+1}. " + "More content here. " * 5,
    author: User.all.sample.email,
    post: Post.all.sample
  )
end
puts "10 Comments created."
